# Results Appendix

- Experiment JSON count: 9
- Report CSV count: 11
- Archive: final_results_20260409_084906.tar.gz
- Manifest: final_results_20260409_084906_manifest.sha256
